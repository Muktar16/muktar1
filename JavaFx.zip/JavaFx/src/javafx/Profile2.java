/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author mukter
 */
public class Profile2 extends Application{
    
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        VBox vbox = new VBox();
        vbox.setMinSize(500, 500);
        vbox.setAlignment(Pos.TOP_CENTER);
        vbox.setSpacing(25);
        
        //Hbox1
        HBox hbox1 = new HBox();
        hbox1.setAlignment(Pos.BASELINE_CENTER);
        hbox1.setSpacing(20);
        Label lab1 = new Label("NAME:  ");
        TextField textField1 = new TextField();
        textField1.setMinWidth(300);
        hbox1.getChildren().addAll(lab1,textField1);
        
        
        //HBox2
        HBox hbox2 = new HBox();
        hbox2.setAlignment(Pos.BASELINE_CENTER);
        hbox2.setSpacing(20);
        Label lab2 = new Label("E-Mail:  ");
        TextField textField2 = new TextField();
        textField2.setMinWidth(300);
        hbox2.getChildren().addAll(lab2,textField2);
        
        //Hbox3
        HBox hbox3 = new HBox();
        hbox3.setAlignment(Pos.BASELINE_CENTER);
        hbox3.setSpacing(20);
        Label lab3 = new Label("Gender:   ");
        RadioButton rButton = new RadioButton("Male");
        RadioButton rButton2 = new RadioButton("Female");
        hbox3.getChildren().addAll(lab3,rButton,rButton2);
        
        
        //HBox4
        HBox hbox4 = new HBox();
        hbox4.setAlignment(Pos.BASELINE_CENTER);
        hbox4.setSpacing(20);
        Label label4 = new Label("About:  ");
        TextArea textArea = new TextArea();
        textArea.setMaxSize(300, 300);
        hbox4.getChildren().addAll(label4,textArea);
        //RadioButton rButton = new RadioButton("Male");
        //RadioButton rButton2 = new RadioButton("Female");
        
        
        
        vbox.getChildren().addAll(hbox1,hbox2,hbox3,hbox4);
        Scene scene = new Scene(vbox);
        
        primaryStage.setScene(scene);
        primaryStage.show();
        
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}