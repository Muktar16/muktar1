package javafx;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ProfileInfo extends Application {
    
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage){
        //stage.setTitle("JavaFX WELCOME");

        //create grid
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(15);
        grid.setVgap(15);
        //grid.setPadding(new Insets(25,25,25,25));

        //create title text
        //Text sceneTitle = new Text("Welcome");
       // sceneTitle.setFont(Font.font("Thoma", FontWeight.NORMAL, 20));
        //grid.add(sceneTitle, 0,0,2,1);

        //username
        Label username = new Label("Name: ");
        grid.add(username, 0,1);

        TextField userTextField = new TextField();
        grid.add(userTextField, 1,1);

        //email
        Label email = new Label("Email :");
        grid.add(email, 0,2);

        TextField emailField = new TextField();
        grid.add(emailField, 1,2);

        //password
        Label password = new Label("Password :");
        grid.add(password, 0, 3);

        PasswordField passwordField = new PasswordField();
        grid.add(passwordField, 1,3);

        //batch
        Label batch = new Label("Batch :");
        grid.add(batch, 0, 4);

        ObservableList<String> batchOptions = FXCollections.observableArrayList("08", "09", "10", "11", "12");
        ComboBox comboBox = new ComboBox(batchOptions);
        comboBox.setValue("08");
        grid.add(comboBox, 1, 4);

        //gender
        Label gender = new Label("Gender :");
        grid.add(gender,0, 5);

        ToggleGroup group = new ToggleGroup();

        RadioButton male = new RadioButton("Male");
        male.setToggleGroup(group);
        male.setSelected(true);
        RadioButton female = new RadioButton("Female");
        female.setToggleGroup(group);
        HBox hBox1 = new HBox(5);
        hBox1.getChildren().addAll(male, female);
        grid.add(hBox1, 1, 5);

        //about
        Label about = new Label("About :");
        grid.add(about, 0, 6);

        TextArea textArea = new TextArea();
        textArea.setPrefSize(200, 100);
        grid.add(textArea, 1,6);

        Button cancelButton = new Button("Cancel");
        Button okButton = new Button("Ok");
        Button clearButton = new Button("Clear");
        HBox hBox = new HBox(20);
        hBox.setAlignment(Pos.BOTTOM_RIGHT);
        hBox.getChildren().addAll(clearButton,okButton,cancelButton);
        grid.add(hBox, 1,10);

        Label okActionTarget = new Label();
        grid.add(okActionTarget, 1,12);

        clearButton.setOnAction(new EventHandler <ActionEvent>() {
            @Override
            public void handle(ActionEvent e){
                userTextField.setText("");
                emailField.setText("");
                passwordField.setText("");
                textArea.setText("");
                comboBox.setValue("08");
                male.setSelected(true);
                okActionTarget.setText("");
            }
        });

        okButton.setOnAction(new EventHandler <ActionEvent>() {
            @Override
            public void handle(ActionEvent e){
                okActionTarget.setText("Successfully Saved");
            }
        });

        cancelButton.setOnAction(new EventHandler <ActionEvent>() {
            @Override
            public void handle(ActionEvent e){
               System.exit(0);
            }
        });

        Scene scene = new Scene(grid, 500,500);
        stage.setScene(scene);

        stage.show();
    }
}