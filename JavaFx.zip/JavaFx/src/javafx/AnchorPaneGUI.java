
package javafx;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class AnchorPaneGUI extends Application {
    
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        primaryStage.setTitle("Wilcome to AnchorPane.");
        
        AnchorPane pane = new AnchorPane();
        pane.setMinSize(300, 300);
        
        Button btn = new Button("Ok");
        btn.setLayoutX(50);
        btn.setLayoutY(10);
        
        TextField textField = new TextField();
        textField.setMaxWidth(300);
        textField.setLayoutX(100);
        textField.setLayoutY(10);
        
        pane.getChildren().addAll(btn, textField);
        
        Scene scene = new Scene(pane);
        
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
