
package javafx;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class BorderPaneGUI extends Application{
    
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        
         BorderPane pane = new BorderPane();
         pane.setMinSize(400, 300);
         
         VBox vbox = new VBox();
         vbox.setMinSize(400, 50);
         vbox.setStyle("-fx-background-color : red");         
         
         HBox hbox = new HBox();
         hbox.setMinSize(400, 50);
         hbox.setStyle("-fx-background-color : green");
         
         VBox vbox2 = new VBox();
         vbox2.setMinSize(50, 200);
         vbox2.setStyle("-fx-background-color : yellow");
         
         HBox hbox2 = new HBox();
         hbox2.setMinSize(50, 200);
         hbox2.setStyle("-fx-background-color : yellow");
         
         VBox vbox3 = new VBox();
         vbox3.setMinSize(300, 200);
         vbox3.setStyle("-fx-background-color : brown");
         
         pane.setTop(vbox);
         pane.setBottom(hbox);
         pane.setRight(vbox2);
         pane.setLeft(hbox2);
         pane.setCenter(vbox3);
         
         
         Scene scene = new Scene(pane);
         
         primaryStage.setScene(scene);
         primaryStage.show();
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
