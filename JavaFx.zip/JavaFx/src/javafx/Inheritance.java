
package javafx;


public class Inheritance {
    
    public static void main(String[] args) {
        
        Calculation c = new Calculation();
        
        
        System.out.println(c.add(20, 30));
        System.out.println(c.substraction(50, 60));
        System.out.println(c.multiply(4, 6));
        System.out.println(c.division(43, 6));
    }
}
