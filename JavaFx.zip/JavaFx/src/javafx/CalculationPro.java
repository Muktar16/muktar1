
package javafx;


public class CalculationPro {

    public CalculationPro() {
        System.out.println("This is constructor of CalculationPro class.");
    }
    
    
    
    public double multiply(double number1, double number2){
        return number1*number2;
    }
    
    
    public double division(double number1, double number2){
        return number1/number2;
    }
    
}
