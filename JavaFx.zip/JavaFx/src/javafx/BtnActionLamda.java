

package javafx;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class BtnActionLamda extends Application {
    
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
       
        VBox vbox = new VBox();
        vbox.setMinSize(500, 300);
        vbox.setSpacing(8);
        vbox.setAlignment(Pos.CENTER);
        
        TextField textField = new TextField();
        textField.setMaxWidth(350);
        
        Button btn = new Button("Ok");
        
        Label label = new Label();
        
        btn.setOnAction(e-> buttonAction(label,textField));
        
        
        vbox.getChildren().addAll(textField,btn,label);
        
        Scene scene = new Scene(vbox);
        
        primaryStage.setScene(scene);
        primaryStage.show();
        
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    void buttonAction(Label lbl,TextField textField){
        lbl.setText("Hellow : "+textField.getText());
    }
    
    
}
