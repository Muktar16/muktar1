package javafx;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class ProfileForm extends Application{
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        AnchorPane pane = new AnchorPane();
        pane.setMinHeight(500);
        pane.setMinWidth(500);
        
        Label label1 = new Label("Name");
        label1.setLayoutX(50);
        label1.setLayoutY(3);
        
        TextField textField = new TextField();
        textField.setLayoutX(110);
        
        Label label2 = new Label("E-mail");
        label2.setLayoutX(50);
        label2.setLayoutY(43);
        
        TextField textField2 = new TextField();
        textField2.setLayoutX(110);
        textField2.setLayoutY(40);
        
        Label label3 = new Label("Gender");
        label3.setLayoutX(50);
        label3.setLayoutY(100);
        
        RadioButton rButton1 = new RadioButton("Male");
        rButton1.setLayoutX(105);
        rButton1.setLayoutY(100);
        
        RadioButton rButton2 = new RadioButton("Female");
        rButton2.setLayoutX(175);
        rButton2.setLayoutY(100);
        
        Label label4 = new Label("About");
        label4.setLayoutX(50);
        label4.setLayoutY(140);
        
        TextField textField3 = new TextField();
        textField3.setAlignment(Pos.TOP_LEFT);
        textField3.setMinHeight(100);
        textField3.setMaxWidth(500);
        textField3.setLayoutX(110);
        textField3.setLayoutY(135);
        
        pane.getChildren().addAll(label1,textField,label2,textField2,label3,rButton1,rButton2,label4,textField3);
                
        
        Scene scene = new Scene(pane);
        
        primaryStage.setScene(scene);
        primaryStage.show();
        
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}