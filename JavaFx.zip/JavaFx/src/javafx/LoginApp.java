/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import static javafx.scene.layout.Region.USE_COMPUTED_SIZE;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Muktar
 */
public class LoginApp extends Application{
    
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        BorderPane pane = new BorderPane();
        pane.setMinSize(700, 400);
        
        VBox vbox = new VBox();
        vbox.setMinHeight(100);
        vbox.setMinWidth(USE_COMPUTED_SIZE);
        vbox.setStyle("-fx-border-color: red;-fx-border-width: 0 0 1 0; -fx-background-color: whitesmoke");
        
        VBox vbox2 = new VBox();
        vbox2.setAlignment(Pos.CENTER);
        vbox2.setMinSize(USE_COMPUTED_SIZE, USE_COMPUTED_SIZE);
        vbox2.setSpacing(10);
        
        TextField userName = new TextField();
        userName.setMaxWidth(400);
        TextField password = new TextField();
        password.setMaxWidth(400);
        
        Button login = new Button("Log in");
        Label label = new Label();
        
        login.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                
                String userField = userName.getText();
                String passwordField = password.getText();
                
                if(userField.equals("Muktar16") && passwordField.equals("163552")){
                    label.setText("Successful");
                }
                else label.setText("Wrong!!");
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        vbox2.getChildren().addAll(userName,password,login,label);
        
        pane.setTop(vbox);
        pane.setCenter(vbox2);
        Scene scene = new Scene(pane);
        
        primaryStage.setScene(scene);
        primaryStage.show();
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
